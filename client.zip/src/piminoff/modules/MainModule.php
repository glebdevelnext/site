<?php
namespace piminoff\modules;

use httpclient;
use std, gui, framework, piminoff;

class MainModule extends AbstractModule
{

    private $server = "http://server.net/api.php";
    private $email = "";
    private $pass = "";
    
    function getStatusServer(){
        $client = new HttpClient;
        $client->responseType = 'JSON';
        $client->postAsync($this->server."?func=status",[],function (HttpResponse $response){
            $res = $response->body();
            if ($response->statusCode() != 200){
                echo "[ERROR] Произошла ошибка при доступе к серверу\n";
                UXDialog::showAndWait("Произошла ошибка при доступе к серверу","ERROR");
                app()->shutdown();
                return 1;
            }
            
            if ($res["status"] == 1){
                echo "[INFO] Server operation mode: ".$res["data"]["mode"]."\n";
                echo "[INFO] PHP Version: ".$res["data"]["php"]."\n";
                app()->form("MainForm")->toast($res["data"]["msg"]);
            } else {
                UXDialog::showAndWait($res["data"]["msg"],"ERROR");
                app()->shutdown();
            }
            app()->form("MainForm")->hidePreloader();
        });
    }
    
    function AuthUser($email,$pass){
        $client = new HttpClient();
        $this->email = $email;
        $this->pass = $pass;
        $client->responseType = 'JSON';
        $client->postAsync($this->server."?func=auth", [
            'email' => $email,
            'pass'  => $pass,
            'auth'  => 1
        ], function (HttpResponse $response) use ($email) {
            $res = $response->body();
            if ($response->statusCode() != 200){
                echo "[ERROR] Произошла ошибка при доступе к серверу\n";
                UXDialog::showAndWait("Произошла ошибка при доступе к серверу","ERROR");
                app()->form("MainForm")->hidePreloader();
                return 1;
            } elseif ($res["status"] != 1){
                echo "[ERROR] ".$res["data"]["msg"]."\n";
                UXDialog::showAndWait($res["data"]["msg"],"ERROR");
                app()->form("MainForm")->hidePreloader();
                return 1;
            } else {
                echo "[INFO] ".$res["data"]["msg"]."\n";
                app()->form("MainForm")->hidePreloader();
                $this->ini->set("email",$email);
                app()->form("MainForm")->loadForm('userInfo', false, true);
                app()->form("userInfo")->toast($res["data"]["msg"]);
                app()->form("userInfo")->name->text = $res["data"]["user"]["name"];
                app()->form("userInfo")->surname->text = $res["data"]["user"]["surname"];
                app()->form("userInfo")->email->text = $res["data"]["user"]["email"];
                app()->form("userInfo")->timereg->text = $res["data"]["user"]["timereg"];
                app()->form("userInfo")->timelast->text = $res["data"]["user"]["timelast"];
                if ($res["data"]["user"]["admin"] > 0){
                    app()->form("userInfo")->admin->visible = true;
                }
                return 1;
            }
        });
    }
    
    function RegUser($email,$pass,$rpass,$name,$surname){
        $client = new HttpClient;
        $client->responseType = 'JSON';
        $client->postAsync($this->server."?func=reg",[
            "email"        => $email,
            "pass"         => $pass,
            "rpass"        => $rpass,
            "name"         => $name,
            "surname"      => $surname,
            "reg"          => 1
        ],function (HttpResponse $response) use ($email,$pass){
            $res = $response->body();
            if ($response->statusCode() != 200){
                echo "[ERROR] Произошла ошибка при доступе к серверу\n";
                UXDialog::showAndWait("Произошла ошибка при доступе к серверу","ERROR");
                app()->form("regForm")->hidePreloader();
                return 1;
            } elseif ($res["status"] != 1){
                echo "[ERROR] ".$res["data"]["msg"]."\n";
                UXDialog::showAndWait($res["data"]["msg"],"ERROR");
                app()->form("regForm")->hidePreloader();
                return 1;
            } else {
                echo "[INFO] ".$res["data"]["msg"]."\n";
                
                app()->form("regForm")->hidePreloader();
                $this->ini->set("email",$email);
                app()->form("regForm")->loadForm('MainForm', false, true);
                app()->form("MainForm")->toast($res["data"]["msg"]);
                $this->AuthUser($email,$pass);
                return 0;
            }
        });
    }
    
    
    /**
     * @event ini.construct 
     */
    function doIniConstruct(ScriptEvent $e = null)
    {    
        if ($this->ini->get("email") == NULL){
            $this->ini->set("email","");
        }
    }
}
