<?php
namespace piminoff\modules;

use std, gui, framework, piminoff;


class AppModule extends AbstractModule
{

}