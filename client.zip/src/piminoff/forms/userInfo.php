<?php
namespace piminoff\forms;

use std, gui, framework, piminoff;


class userInfo extends AbstractForm
{

    /**
     * @event link3.click 
     */
    function doLink3Click(UXMouseEvent $e = null)
    {
        browse('http://dnext.ga');
    }

    /**
     * @event linkAlt.click 
     */
    function doLinkAltClick(UXMouseEvent $e = null)
    {
        browse('http://dnext.ga');
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        app()->shutdown();
    }




}
