<?php
namespace piminoff\forms;

use std, gui, framework, piminoff;


class regForm extends AbstractForm
{

    /**
     * @event link3.click 
     */
    function doLink3Click(UXMouseEvent $e = null)
    {    
        browse('http://dnext.ga');
    }

    /**
     * @event linkAlt.click 
     */
    function doLinkAltClick(UXMouseEvent $e = null)
    {    
        browse('http://dnext.ga');
    }

    /**
     * @event link.click 
     */
    function doLinkClick(UXMouseEvent $e = null)
    {    
        $this->loadForm('MainForm', false, true);
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $this->showPreloader("Registration...");
        $this->RegUser($this->email->text,$this->pass->text,$this->rpass->text,$this->name->text,$this->surname->text);
    }

}
