<?php
namespace piminoff\forms;

use std, gui, framework, piminoff;


class MainForm extends AbstractForm
{

    /**
     * @event link3.click 
     */
    function doLink3Click(UXMouseEvent $e = null)
    {    
        browse('http://dnext.ga');
    }

    /**
     * @event linkAlt.click 
     */
    function doLinkAltClick(UXMouseEvent $e = null)
    {    
        browse('http://dnext.ga');
    }

    /**
     * @event link.click 
     */
    function doLinkClick(UXMouseEvent $e = null)
    {    
        $this->loadForm('regForm', false, true);
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        $this->showPreloader("Checking the connection to the server...");
        $this->getStatusServer();
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->email->text = $this->ini->get("email");
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $this->showPreloader("Log in to your account...");
        $this->AuthUser($this->email->text,$this->pass->text);
    }

}
