<?php
require_once './INIStorage.php';
class APIDriver extends INIStorage
{
    private $db = null;
    private $usersPath = "./users/";
    private $Storage;
    function __construct($dirpath="./users/")
    {
        $this->usersPath = $dirpath;
        
    }
    
    function GetError(){
        // Заглушка для поддержки других режимов
        return false;
    }
    
    function Repair(){
        if (!file_exists($this->usersPath) || !is_dir($this->usersPath)) {
            @unlink($this->usersPath);
            mkdir($this->usersPath,0777,true);
        }
    }
    
    
    function useEmail($email){
        return file_exists($this->usersPath."/".$email.".ini");
    }
    
    function PreparingString($string){
        return ($string);
    }
    
    function RegUser($email,$pass,$name,$surname){
        parent::__construct($this->usersPath."/".$email.".ini",1,1);
        parent::set("email",$email);
        parent::set("pass",$pass);
        parent::set("name",$name);
        parent::set("surname",$surname);
        parent::set("timereg",time());
        parent::set("timelast",time());
        parent::set("admin",0);
        parent::save();
    }
    
    function CountRows($from=null,$where=null){
        $count = 0;
        if (is_dir($this->usersPath)) {
            if ($dh = opendir($this->usersPath)) {
                while (($file = readdir($dh)) !== false) {
                    if (filetype($this->usersPath.$file) == "ini"){
                        $count++;
                    }
                }
                closedir($dh);
            }
        }
        return $count;
    }
    
    function AuthUser($email,$pass){
        $email = $this->PreparingString($email);
        $pass  = $this->PreparingString($pass);
        if (!$this->useEmail($email)){
            return false;
        }
        parent::__construct($this->usersPath."/".$email.".ini",0,1);
        $ini_pass = parent::get("pass");
        if ($ini_pass != $pass){
            return false;
        }
        parent::set("timelast",time());
        parent::save();
        return true;
    }
    
    function GetUserInfo($email,$pass){
        if (!$this->AuthUser($email,$pass)){
            return false;
        }
        parent::__construct($this->usersPath."/".$email.".ini",0,1);
        return parent::toArray();
    }
}
?>