<?php
error_reporting(E_ALL | E_STRICT) ;
ini_set('display_errors', 'On');
# Настройки подключения
# MODE - Определяет в какой режим БД использовать
# 0 - MySQL (должен присутствовать рядом файл api.mysql.php)
# 1 - SQLite (должен присутствовать рядом файл api.sqlite.php)
# 2 - Файловая на основе INI (должен присутствовать рядом файл api.ini.php и iniStorage.php)
define("MODE",2);

# Настройки для MySQL режима
# Адрес сервера - По умочанию (localhost или 127.0.0.1), если иное не указано вашим провайдером
define("MYSQL_HOST","localhost");
# Название базы данных
define("MYSQL_NAME","x_scripts_apiauth");
# Логин базы данных
define("MYSQL_USER","x_scripts_apiauth");
# Пароль базы данных
define("MYSQL_PASS","8S2n3U0c");

# Настройки для SQLite режима
# Путь к файлу базе данных - По умолчанию (./api.sqlite.db)
define("SQLITE_PATH","./api.sqlite.db");

# Настройки для INIStorage
# Путь к папке, где будут хранится пользователи
define("INI_FOLDER_PATH","./users/");
// Дальше без необходимости не лезем
function json_out($status,$return=null){
    $json = ["status"=>$status];
    if ($return != null){
        $json["data"] = $return;
    }
    echo json_encode($json);
    exit();
}

function err($msg="Unknown error!"){
    json_out(-1,["msg"=>$msg]);
}

function systemError($exception){
    err("A critical error occurred while executing the request! More detailed: ".$exception->getMessage());
}
function xss($text){
    return trim(htmlspecialchars($text));
}
function passHash($string){
    $pass = md5(md5($string));
    $count_1 = strlen($pass);
    $return = NULL;
    for($i = 1; $i <= $count_1; $i++) {
        $n = ($i == 1 ? 0 : $i-1);
        $return .= md5(md5(substr($pass, $n, $i)));
    }
    return md5($return);
}
set_exception_handler('systemError');

// Проверяем наличие файлов для работы
if ((!file_exists("./api.mysql.php") && MODE == 0) || (!file_exists("./api.sqlite.php") && MODE == 1) || (!file_exists("./api.ini.php") && MODE == 2) || MODE < 0 || MODE > 2) {
    err("Files to work with for data with the database type (".MODE.") were not found. Check the configuration for the API.");
}
if (MODE == 0){
    include_once './api.mysql.php';
    $driver = new APIDriver(MYSQL_NAME,MYSQL_USER,MYSQL_PASS,MYSQL_HOST);
    
} elseif (MODE == 1){
    include_once './api.sqlite.php';
    $driver = new APIDriver(SQLITE_PATH);
} elseif (MODE == 2){
    include_once './api.ini.php';
    $driver = new APIDriver(INI_FOLDER_PATH);
}
if ($driver->getError() != false){
    err("Sorry, but the database server is unavailable! Please contact the server administrator.");
}
$driver->Repair();
$cmd = isset($_GET["func"]) && !empty($_GET["func"])?xss($_GET["func"]):"status";
switch($cmd){
    case "status": {
        json_out(1,[
            "msg"   =>  "Connection successfully established.",
            "mode"  =>  MODE,
            "php"   =>  phpversion()
        ]);
    }
    case "reg": {
        if (!isset($_POST["reg"])){
            err("The method is unsupported.");
        } elseif (!isset($_POST["name"]) || empty($_POST["name"])){
            err("You must fill in the \"Name\" field");
        } elseif (!isset($_POST["surname"]) || empty($_POST["surname"])){
            err("You must fill in the \"Surname\" field");
        } elseif (!isset($_POST["email"]) || empty($_POST["email"])){
            err("You must fill in the \"Email\" field");
        } elseif (!isset($_POST["pass"]) || empty($_POST["pass"])){
            err("You must fill in the \"Password\" field");
        } elseif (!isset($_POST["rpass"]) || empty($_POST["rpass"])){
            err("You must fill in the \"Repeat the password\" field");
        } elseif ($_POST["pass"] != $_POST["rpass"]){
            err("The passwords don't match.");
        } elseif (!filter_var(xss($_POST["email"]), FILTER_VALIDATE_EMAIL)){
            err("The email address is incorrect!");
        } elseif ($driver->useEmail(xss($_POST["email"]))){
            err("This email address is busy.");
        } else {
            $name       = xss($_POST["name"]);
            $surname    = xss($_POST["surname"]);
            $email      = xss($_POST["email"]);
            $pass       = passHash($_POST["pass"]);
            $driver->RegUser($email,$pass,$name,$surname);
            json_out(1,[
                "msg"   =>  "Registration was completed successfully.",
            ]);
        }
    }
    case "auth": {
        if (!isset($_POST["auth"])){
            err("The method is unsupported.");
        } elseif (!isset($_POST["email"]) || empty($_POST["email"])){
            err("You must fill in the \"Email\" field");
        } elseif (!isset($_POST["pass"]) || empty($_POST["pass"])){
            err("You must fill in the \"Password\" field");
        } elseif (!filter_var(xss($_POST["email"]), FILTER_VALIDATE_EMAIL)){
            err("The email address is incorrect!");
        } elseif (!$driver->AuthUser(xss($_POST["email"]),passHash($_POST["pass"]))){
            err("The account was not found in the database.");
        } else {
            $user_data = $driver->GetUserInfo(xss($_POST["email"]),passHash($_POST["pass"]));
            unset($user_data["passwd"]); // Удаляем пароль, чтобы он не уходил на клиент.
            json_out(1,[
                "msg"   =>  "Welcome back, ".$user_data["name"]."!",
                "user"  =>  $user_data
            ]);
        }
    }
    case "userInfo": {
        if (!isset($_POST["email"]) || empty($_POST["email"])){
            err("Information from the client was not sent. Error #0");
        } elseif (!isset($_POST["pass"]) || empty($_POST["pass"])){
            err("Information from the client was not sent. Error #1");
        } else {
            $user_data = $driver->GetUserInfo(xss($_POST["email"]),passHash($_POST["pass"]));
            unset($user_data["passwd"]); // Удаляем пароль, чтобы он не уходил на клиент.
            json_out(1,$user_data);
        }
    }
    default: {
        err("The command was not found or is unsupported by the server.");
    }
}
?>