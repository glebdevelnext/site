<?php
class APIDriver
{
    private $db = null;
    private $error = "";
    function __construct($name="piminoff",$login="root",$pwd="",$host="localhost")
    {
        @$db = mysqli_connect($host,$login,$pwd,$name);
        if (!$db) {
            $this->error = mysqli_connect_error();
            return false;
        } else {
            $this->db = $db;
            $this->Query("SET NAMES 'utf8'");
            return true;
        }
    }
    
    /**
     * Получить информацию об ошибке
     * @return false|string - Строка с ошибкой иначе false
     */
    function GetError(){
        if ($this->error != ""){
            return $this->error;
        } else {
            return false;
        }
    }
    
    function Repair(){
        $this->db->Query("CREATE TABLE IF NOT EXISTS `users` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID ',
          `email` varchar(255) NOT NULL COMMENT 'Эл.почта',
          `passwd` varchar(255) NOT NULL COMMENT 'Пароль',
          `name` varchar(255) NOT NULL COMMENT 'Имя',
          `surname` varchar(255) NOT NULL COMMENT 'Фамилия',
          `timereg` int(11) NOT NULL COMMENT 'Дата регистрации',
          `timelast` int(11) NOT NULL COMMENT 'дата посл. посещения',
          `admin` int(11) NOT NULL COMMENT 'Уровень доступа',
          PRIMARY KEY (`id`),
          UNIQUE KEY `id` (`id`),
          KEY `id_2` (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;");
    }
    
    /**
     * Выполнить запрос в базу даныных
     * @param $sql - Запрос SQL
     * @return bool|\mysqli_result - Результат SQL-запроса
     */
    function Query($sql){
        return mysqli_query($this->db,$sql);
    }
    
    /**
     * Получить строчки
     * @param $sql - Запрос к базе данных
     * @return string[]|null - Строчки, впротивном случаи null
     */
    function Fetch($sql){
        return mysqli_fetch_assoc($this->Query($sql));
    }

    /**
     * Получить строчку по ID из таблицы
     * @param $from - Таблица
     * @param int $id - ID
     * @param string $prefix - Прейфикс
     * @return string[]|null - Получить данные о строчке
     */
    function GetByID($from,$id=1,$prefix="id"){
        return mysqli_fetch_assoc($this->Query("SELECT * FROM `".$from."` WHERE `".$prefix."` = '$id' LIMIT 1"));
    }

    /**
     * Обработка SQL-строки
     * @param $string - Строка которую надо защитить
     * @return string - Строка
     */
    function PreparingString($string){
        return mysqli_real_escape_string($this->db,$string);
    }
    
    /**
     * Узнать количество строчек по условию
     * @param $from - Таблица
     * @param null $where - Условие
     * @return int - Количество строчек
     */
    function CountRows($from,$where=null){
        $count = $this->Query("SELECT * FROM `".$from."` ".$where);
        return mysqli_num_rows($count);
    }
    
    function useEmail($email){
        $count = $this->GetByID("users",$this->PreparingString($email),"email");
        return $count>0?true:false;
    }
    
    function RegUser($email,$pass,$name,$surname){
        $this->Query('INSERT INTO `users`(`email`, `passwd`, `name`, `surname`, `timereg`, `timelast`) VALUES ("'.$this->PreparingString($email).'","'.$this->PreparingString($pass).'","'.$this->PreparingString($name).'","'.$this->PreparingString($surname).'","'.(time()).'","'.(time()).'")');
    }
    
    function AuthUser($email,$pass){
        $email = $this->PreparingString($email);
        $pass  = $this->PreparingString($pass);
        if ($this->CountRows("users","WHERE `email` = '$email' AND `passwd` = '$pass'") == 0){
            return false;
        }
        $this->Query("UPDATE `users` SET `timelast`='".(time())."' WHERE `email` = '$email' AND `passwd` = '$pass'");
        return true;
    }
    
    function GetUserInfo($email,$pass){
        if (!$this->AuthUser($email,$pass)){
            return false;
        }
        return $this->GetByID("users",$email,"email");
    }
}
?>