<?php
class APIDriver
{
    private $db = null;
    private $error = "";
    function __construct($path="./api.sqlite.db")
    {
        @$db = new PDO('sqlite:'.$path); 
        $this->db = $db;
    }
    
    function GetError(){
        // Заглушка для поддержки других режимов
        return false;
    }
    
    function Repair(){
        $this->db->query("CREATE TABLE IF NOT EXISTS `users` (`email` varchar(255), `passwd` varchar(255),`name` varchar(255),`surname` varchar(255),`timereg` int(11),`timelast` int(11) ,`admin` int(11));");
    }
    
    function Query($sql){
        $this->db->query($sql);
    }
    
    function Fetch($sql){
        $st = $this->db->query($sql);
        $results = $st->fetchAll();
        return $results[0];
    }
    
    function useEmail($email){
        $count = $this->db->query("SELECT * FROM `users` WHERE `email` = '$email'");
        return $count==null?true:false;
    }
    
    function PreparingString($string){
        return ($string);
    }
    
    function RegUser($email,$pass,$name,$surname){
        $this->db->query('INSERT INTO `users`(`email`, `passwd`, `name`, `surname`, `timereg`, `timelast`) VALUES ("'.$this->PreparingString($email).'","'.$this->PreparingString($pass).'","'.$this->PreparingString($name).'","'.$this->PreparingString($surname).'","'.(time()).'","'.(time()).'")');
    }
    
    function CountRows($from,$where=null){
        $count = $this->db->query("SELECT * FROM `".$from."` ".$where);
        return count($count->fetchAll());
    }
    
    function AuthUser($email,$pass){
        $email = $this->PreparingString($email);
        $pass  = $this->PreparingString($pass);
        if ($this->CountRows("users","WHERE `email` = '$email' AND `passwd` = '$pass'") == 0){
            return false;
        }
        $this->Query("UPDATE `users` SET `timelast`='".(time())."' WHERE `email` = '$email' AND `passwd` = '$pass'");
        return true;
    }
    
    function GetUserInfo($email,$pass){
        if (!$this->AuthUser($email,$pass)){
            return false;
        }
        return $this->Fetch("SELECT * FROM `users` WHERE `email` = '$email'");
    }
}
?>